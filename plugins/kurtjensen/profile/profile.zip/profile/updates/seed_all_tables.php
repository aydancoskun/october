<?php namespace KurtJensen\Profile\Updates;

use October\Rain\Database\Updates\Seeder;
use KurtJensen\Profile\Models\Settings;

class SeedAllTables extends Seeder
{

    public function run()
    {

    }

}
